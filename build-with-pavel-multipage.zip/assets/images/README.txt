Put local images here (optional). Current design uses external images.
